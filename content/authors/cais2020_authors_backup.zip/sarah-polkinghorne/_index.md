---
title: Sarah Polkinghorne
role: University of Alberta Libraries, University of Alberta & Swinburne University of Technology (Australia)
avatar_filename: avatar.jpg
bio: Sarah Polkinghorne is a librarian at the University of Alberta and a doctoral student at Swinburne University of Technology. Her research focuses on everyday information practices, particularly practices that are tacit, unexamined, or assumed to be mundane.
superuser: false
user_groups:
  - Authors
---
# Bio

Sarah Polkinghorne is a librarian at the University of Alberta and a doctoral student at Swinburne University of Technology. Her research focuses on everyday information practices, particularly practices that are tacit, unexamined, or assumed to be mundane.
