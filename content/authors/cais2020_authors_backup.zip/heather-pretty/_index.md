---
title: Heather J. Pretty
role: Memorial University of Newfoundland
avatar_filename: avatar.jpg
bio: Heather Pretty is a Cataloguing Librarian at Memorial University of Newfoundland where her primary responsibilities include catalogue maintenance and authorities. In addition, Heather is coordinator of the Atlantic Canada Funnel of the Program for Cooperative Cataloging (PCC) Name Authority Cooperative Program (NACO), an At-Large Member of the PCC Policy Committee, and Chair of the Canadian BIBFRAME Readiness Task Force.
superuser: false
user_groups:
  - Presenters
  - Authors
---
# Bio

Heather Pretty is a Cataloguing Librarian at Memorial University of Newfoundland where her primary responsibilities include catalogue maintenance and authorities. In addition, Heather is coordinator of the Atlantic Canada Funnel of the Program for Cooperative Cataloging (PCC) Name Authority Cooperative Program (NACO), an At-Large Member of the PCC Policy Committee, and Chair of the Canadian BIBFRAME Readiness Task Force.
