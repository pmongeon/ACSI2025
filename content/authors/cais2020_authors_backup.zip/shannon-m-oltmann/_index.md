---
title: Shannon M. Oltmann
role: School of Information Science, University of Kentucky
avatar_filename: avatar.jpg
bio: Shannon M. Oltmann is an associate professor at the University of Kentucky. She has published a book, _Practicing Intellectual Freedom for Libraries_, and numerous articles. Her work focuses on intellectual freedom, censorship, and information ethics.
superuser: false
user_groups:
  - Authors
---
# Bio

Shannon M. Oltmann is an associate professor at the University of Kentucky. She has published a book, _Practicing Intellectual Freedom for Libraries_, and numerous articles. Her work focuses on intellectual freedom, censorship, and information ethics.
