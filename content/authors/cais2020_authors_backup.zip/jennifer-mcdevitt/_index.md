---
title: Jennifer McDevitt
avatar_filename: avatar.jpg
superuser: false
user_groups:
  - Authors
---
