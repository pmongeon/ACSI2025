---
title: Amber Dierking
role: University Libraries, Grand Valley State University
avatar_filename: avatar.jpg
bio: Amber Dierking is the Humanities & Arts Liaison Librarian at Grand Valley State University, MI. While always fascinated by invisible infrastructures, systematic biases, and the alternative possibilities we can imagine, she plans to center her future research around the histories of queer community libraries.
superuser: false
user_groups:
  - Presenters
  - Authors
---
# Bio

Amber Dierking is the Humanities & Arts Liaison Librarian at Grand Valley State University, MI. While always fascinated by invisible infrastructures, systematic biases, and the alternative possibilities we can imagine, she plans to center her future research around the histories of queer community libraries.
