---
title: Beverly Siliuyaq Amos
role: Inuvialuit Cultural Centre
bio: Beverly Siliuyaq Amos is an Inuvialuk from the Inuvialuit Region and who was raised in Sachs Harbour, Banks Island. She is the Regional Language Consultant at the Inuvialuit Cultural Centre, and she has been an Inuvialuktun translator and advocate for over 30 years keeping language and cultural issues in the forefront so they are not forgotten. Voices Project.
avatar_filename: avatar.jpg
superuser: false
user_groups:
  - Authors
---
# Bio
 Beverly Siliuyaq Amos is an Inuvialuk from the Inuvialuit Region and who was raised in Sachs Harbour, Banks Island. She is the Regional Language Consultant at the Inuvialuit Cultural Centre, and she has been an Inuvialuktun translator and advocate for over 30 years keeping language and cultural issues in the forefront so they are not forgotten.