---
title: Erica Finch
role: School of Information Management, Dalhousie University
avatar_filename: avatar.jpg
superuser: false
user_groups:
  - Volunteers
---
