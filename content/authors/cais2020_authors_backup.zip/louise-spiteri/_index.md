---
title: Louise Spiteri
role: School of Information Management, Dalhousie University
avatar_filename: avatar.jpg
bio: Louise Spiteri is a professor in the School of Information Management, Dalhousie University, where she teaches in the areas of metadata, knowledge management, and records and information management. Dr Spiteri’s research interests focus on user-generated metadata, social tagging, library cataloguing, linked data, and zero-waste communities.
superuser: false
user_groups:
  - Presenters
  - Authors
---
# Bio

Louise Spiteri is a professor in the School of Information Management, Dalhousie University, where she teaches in the areas of metadata, knowledge management, and records and information management. Dr Spiteri’s research interests focus on user-generated metadata, social tagging, library cataloguing, linked data, and zero-waste communities.
