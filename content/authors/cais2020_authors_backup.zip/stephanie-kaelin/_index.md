---
title: Stephanie Kaelin
role: Senior Library Sales Manager, Cambridge University Press
bio: ""
avatar_filename: avatar.jpg
superuser: false
user_groups:
  - Authors
---
