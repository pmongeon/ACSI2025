---
title: Alison Harding
role: Department of Information Science, University at Buffalo
avatar_filename: alison_harding_avatar.jpg
superuser: false
groups:
  - Authors
  - Presenters    
---

# Bio
Alison Harding is a master’s student in the Department of Information Science at the University at Buffalo. She is currently researching the information behavior of adolescents, in particular the social and technological information seeking behaviors in urban environments.