---
title: Robyn E. Stobbs
role: University of Alberta
bio: "Robyn Stobbs is an interdisciplinary PhD candidate at the University of Alberta in the fields of Human Ecology and Library and Information Studies. She is a graduate research assistant on the Inuvialuit Voices project."
avatar_filename: avatar.jpg
superuser: false
user_groups:
  - Presenters
  - Authors
---
# Bio
Robyn Stobbs is an interdisciplinary PhD candidate at the University of Alberta in the fields of Human Ecology and Library and Information Studies. She is a graduate research assistant on the Inuvialuit Voices project.
