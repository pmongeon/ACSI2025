---
title: Cora-Lynn Munroe-Lynds
role: School of Information Management, Dalhousie University
avatar_filename: avatar.jpg
superuser: false
user_groups:
  - Volunteers
---
# About me
My name is Cora-Lynn, but you can call me Cora. I am from Chester, Nova Scotia but reside in Bedford with my husband and kitty, Darwin. In my spare time, I enjoy gardening, any activity that involves the ocean, and painting. I finished my undergraduate degree in French and History at Mount Saint Vincent University. I am going into my second year at Dalhousie University in the Master of Information program. My research interests include metaliteracy, information literacy, fake news, social epistemology, and much much more! Bates (1999) divides the information field into three categories: physical, sociological, and design. My research interests revolve around the sociological aspects of information—how people relate, seek, and use information online.
