---
title: Alec Brookes
role: Dept of Modern Languages, Literature and Cultures, Memorial University of Newfoundland
bio: "Alec Brookes is Associate Professor of Russian Literature at Memorial University of Newfoundland. His research pertains to cultural studies, World-Ecology, and Russian literature and film. His research has appeared in October, the Interdisciplinary Study of Literature and the Environment (ISLE), Russian Literature, and Canadian Slavonic Papers."
avatar_filename: avatar.jpg
superuser: false
user_groups:
  - Authors
---

# Bio
Alec Brookes is Associate Professor of Russian Literature at Memorial University of Newfoundland. His research pertains to cultural studies, World-Ecology, and Russian literature and film. His research has appeared in October, the Interdisciplinary Study of Literature and the Environment (ISLE), Russian Literature, and Canadian Slavonic Papers. 