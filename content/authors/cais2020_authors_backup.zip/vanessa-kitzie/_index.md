---
title: Vanessa Kitzie
role: School of Information Science, Univerisity of South Carolina
avatar_filename: avatar.jpg
bio: Vanessa Kitzie is an Assistant Professor at the University of South Carolina School of Information Science. Her research and teaching interests include human information behavior and gender and sexuality studies. She is a recipient of IMLS Early Career Development grant and has published in venues like _JASIST_.
superuser: false
user_groups:
  - Authors
---
# Bio

Vanessa Kitzie is an Assistant Professor at the University of South Carolina School of Information Science. Her research and teaching interests include human information behavior and gender and sexuality studies. She is a recipient of IMLS Early Career Development grant and has published in venues like _JASIST_.
