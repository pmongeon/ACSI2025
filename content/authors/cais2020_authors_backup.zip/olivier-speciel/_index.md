---
title: Olivier Spéciel
role: Services Documentaires Multimédia Inc.
avatar_filename: avatar.jpg
bio: Olivier Spéciel is a librarian and works as Director, IT and innovations at SDM, a nonprofit organization that provides technology services, bibliographic and authority databases to the library community. He is currently a member of the Canadian BIBFRAME Readiness Task Force.
superuser: false
user_groups:
  - Presenters
  - Authors
---
# Bio

Olivier Spéciel is a librarian and works as Director, IT and innovations at SDM, a nonprofit organization that provides technology services, bibliographic and authority databases to the library community. He is currently a member of the Canadian BIBFRAME Readiness Task Force.
