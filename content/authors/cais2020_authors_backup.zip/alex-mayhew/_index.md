---
title: Alex Mayhew
role: Faculty of Information & Media Studies, Western University
avatar_filename: avatar.jpg
bio: "Alex Mayhew is a LIS  PhD candidate in FIMS at UWO. He earned an MLIS in 2016 also at FIMS. Before that he earned an Undergrad degree in Philosophy at the University of Ottawa. He is interested in thinking tools and philosophical engineering, particularly knowledge organization."
superuser: false
user_groups:
  - Presenters
  - Authors
  - Volunteers
---

# Bio

Alex Mayhew is a LIS  PhD candidate in FIMS at UWO. He earned an MLIS in 2016 also at FIMS. Before that he earned an Undergrad degree in Philosophy at the University of Ottawa. He is interested in thinking tools and philosophical engineering, particularly knowledge organization.
