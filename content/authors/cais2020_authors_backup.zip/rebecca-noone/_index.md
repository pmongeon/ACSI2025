---
title: Rebecca Noone
role: Faculty of Information, University of Toronto
avatar_filename: rebecca_noone_avatar.jpeg
superuser: false
user_groups:
  - Presenters
  - Authors
---
