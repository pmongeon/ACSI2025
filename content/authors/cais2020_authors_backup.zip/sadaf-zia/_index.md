---
title: Sadaf Zia
role: Faculty of Information and Media Studies, Western University
avatar_filename: avatar.png
bio: Sadaf Zia is a recent graduate of the Master of Library and Information Science program at Western University. She holds an undergraduate degree from the University of Toronto, where she double majored in Political Science and Philosophy. She is currently working as a branch supervisor for the Mississauga Library System.
superuser: false
user_groups:
  - Presenters
  - Authors
---
# Bio

Sadaf Zia is a recent graduate of the Master of Library and Information Science program at Western University. She holds an undergraduate degree from the University of Toronto, where she double majored in Political Science and Philosophy. She is currently working as a branch supervisor for the Mississauga Library System.
