---
title: Marc-André Simard
role: École de Bibliothéconomie et des sciences de l'information, Université de Montréal
bio: "Marc-André is a Ph.D. student in Information science at the École de bibliothéconomie et des sciences de l’information, Université de Montréal. He holds a Bachelor’s degree in Philosophy (Université Laval) and a Master’s degree in Information Science (Université de Montréal). His research focuses on bibliometrics, open access, and science policy."
avatar_filename: avatar.jpg
superuser: false
user_groups:
  - Volunteers
---

# About Marc-André
Marc-André is a Ph.D. student in Information science at the École de bibliothéconomie et des sciences de l’information, Université de Montréal. He holds a Bachelor’s degree in Philosophy (Université Laval) and a Master’s degree in Information Science (Université de Montréal). His research focuses on bibliometrics, open access, and science policy.