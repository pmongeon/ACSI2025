---
title: Don Latham
role: School of Information, Florida State University
avatar_filename: avatar.jpg
bio: "Don Latham is a professor in the School of Information at Florida State University. His research focuses on information behavior of young adults and digital literacies. He is co-editor of _The Information Literacy Framework: Case Studies of Successful Implementation_ (Rowman & Littlefield, 2020)."
superuser: false
user_groups:
  - Authors
---
# Bio

Don Latham is a professor in the School of Information at Florida State University. His research focuses on information behavior of young adults and digital literacies. He is co-editor of _The Information Literacy Framework: Case Studies of Successful Implementation_ (Rowman & Littlefield, 2020).
