---
title: Brian Detlor
role: DeGroote School of Business, McMaster University
avatar_filename: avatar.jpg
bio: Brian Detlor is Professor and Area Chair (Information Systems) at the DeGroote School of Business at McMaster University. Recent research interests pertain to digital literacy and digital storytelling.
superuser: false
user_groups:
  - Presenters
  - Authors
---
# Bio

Brian Detlor is Professor and Area Chair (Information Systems) at the DeGroote School of Business at McMaster University. Recent research interests pertain to digital literacy and digital storytelling.
