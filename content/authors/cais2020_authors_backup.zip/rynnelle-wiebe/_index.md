---
title: Rynnelle Wiebe
role: School of Library and Information Studies, University of Alberta
bio: "Rynnelle Wiebe is a current Master's of Library and Information Studies student at the School of Library and Information Studies, University of Alberta."
avatar_filename: avatar.jpg
superuser: false
user_groups:
  - Presenters
  - Authors
---

# Bio
Rynnelle Wiebe is a current Master's of Library and Information Studies student at the School of Library and Information Studies, University of Alberta.