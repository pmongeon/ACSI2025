---
title: Celina De Lancey
role: Faculty of Information & Media Studies, Western University
avatar_filename: avatar.jpg
bio: Celina de Lancey is a recent graduate of the Master of Library and Information Science program at Western University.
superuser: false
user_groups:
  - Authors
---
# Bio

Celina de Lancey is a recent graduate of the Master of Library and Information Science program at Western University.
