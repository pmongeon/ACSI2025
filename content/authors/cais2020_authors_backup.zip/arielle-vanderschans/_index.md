---
title: Arielle VanderSchans
role: Faculty of Information & Media Studies, Western University
avatar_filename: avatar.JPG
bio: Arielle VanderSchans is a LIS PhD student in the Faculty of Information Science at Western University. She has a MLIS (2016), a MA in Linguistics (2015), and BA (2013) in English and Linguistics. She is interested in story-crafting and communities of practice. Currently she studies bookbinding through the Canadian Bookbinding and Book Arts Guild of Canada.
superuser: false
user_groups:
  - Presenters
  - Authors
---
# Bio

Arielle VanderSchans is a LIS PhD student in the Faculty of Information Science at Western University. She has a MLIS (2016), a MA in Linguistics (2015), and BA (2013) in English and Linguistics. She is interested in story-crafting and communities of practice. Currently she studies bookbinding through the Canadian Bookbinding and Book Arts Guild of Canada.
