---
title: Lena Kotokak
role: Inuvialuit Cultural Centre
avatar_filename: avatar
bio: Lena Kotokak is the Regional Language Coordinator at the Inuvialuit
  Cultural Centre. She is a collaborator on the Inuvialuit Voices Project.
superuser: false
user_groups:
  - Authors
---
Lena Kotokak is the Regional Language Coordinator at the Inuvialuit Cultural Centre. She is a collaborator on the Inuvialuit Voices Project.