---
title: Sam Trosow
role: "Faculty of Information & Media Studies and Faculty of Law, University of Western Ontario"
avatar_filename: avatar.jpg
bio: 
superuser: false
user_groups:
  - Authors
---

