---
title: Brenda Reyes Ayala
role: Assistant Professor, University of Alberta
bio: Brenda Reyes Ayala is an Assistant Professor at the School of Library and
  Information Studies at the University of Alberta. Her research interests
  include Web Archiving, Digital Humanities, and Information Retrieval.
avatar_filename: "brenda_reyes_ayala_avatar.jpg"
superuser: false
user_groups:
  - Presenters
  - Authors
---
