---
title: Heather Hill
role: Faculty of Information & Media Studies, Western University
avatar_filename: avatar.jpg
bio: Heather Hill is an associate professor in the Faculty of Information and Media Studies at Western University. Her research interests centre on public libraries, accessibility, and fringe literature (fan fiction and self publishing).
superuser: false
user_groups:
  - Presenters
  - Authors
---
# Bio

Heather Hill is an associate professor in the Faculty of Information and Media Studies at Western University. Her research interests centre on public libraries, accessibility, and fringe literature (fan fiction and self publishing).
