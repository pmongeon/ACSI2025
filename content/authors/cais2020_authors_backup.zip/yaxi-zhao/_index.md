---
title: Yaxi Zhao
role: Faculty of Information, University of Toronto
avatar_filename: avatar.jpg
superuser: false
user_groups:
 - Volunteers
---
