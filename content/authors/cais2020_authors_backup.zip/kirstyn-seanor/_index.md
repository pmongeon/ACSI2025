---
title: kirstyn seanor
role: Faculty of Information & Media Studies, Western University
avatar_filename: avatar.jpg
bio: kirstyn seanor is a PhD candidate in Library and Information Science in the Faculty of Information and Media Studies at Western University. Their dissertation work on the user tagging of pornography centres virtual artefacts - such as user tags and website design elements - as evidence of trends in sexual content, user behaviours, and popular discourses.
superuser: false
user_groups:
  - Presenters
  - Authors
---
# Bio

kirstyn seanor is a PhD candidate in Library and Information Science in the Faculty of Information and Media Studies at Western University. Their dissertation work on the user tagging of pornography centres virtual artefacts - such as user tags and website design elements - as evidence of trends in sexual content, user behaviours, and popular discourses.
