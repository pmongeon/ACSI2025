---
title: Mary Greenshields
role: University Library, University of Lethbridge
avatar_filename: avatar.jpg
bio: Mary Greenshields is a librarian at the University of Lethbridge. Her research focuses on love, information literacy, feminism, and the places they meet.
superuser: false
user_groups:
  - Presenters
  - Authors
---
# Bio

Mary Greenshields is a librarian at the University of Lethbridge. Her research focuses on love, information literacy, feminism, and the places they meet.
