---
title: Sara Clarke
role: Faculty of Information & Media Studies, Western University
avatar_filename: avatar.jpg
bio: "Sara Clarke (she/her/hers) is an MLIS candidate in the Faculty of Information and Media
  Studies at Western University and is currently completing a co-op in User
  Experience and Student Engagement with Western Libraries. She was the managing
  editor of Emerging Library and Information Perspectives (ELIP) during the
  2019-2020 academic year."
superuser: false
user_groups:
  - Authors
---
# Bio
Sara Clarke (she/her/hers) is an MLIS candidate in the Faculty of Information and Media Studies at Western University and is currently completing a co-op in User Experience and Student Engagement with Western Libraries. She was the managing editor of Emerging Library and Information Perspectives (ELIP) during the 2019-2020 academic year."
