---
title: Ayodele Alonge
role: Department of Library Archival and Information Studies, University of Ibadan (Nigeria) & Consortium for Advanced Research Training in Africa (Nairobi, Kenya) 
avatar_filename: avatar.jpg
bio: Ayodele is a Library and Information Science Lecturer at the University of Ibadan, Nigeria and Fellow of the Consortium for Advanced Research Training in Africa (CARTA), Nairobi Kenya.  He holds a PhD in Communication and Information Studies University of Nairobi, Kenya; Master of Publishing and Copyright Studies and Bachelor of Library and Information Studies from the University of Ibadan, Nigeria. 
superuser: false
user_groups:
  - Presenters
  - Authors
---
# Bio

Ayodele is a Library and Information Science Lecturer at the University of Ibadan, Nigeria and Fellow of the Consortium for Advanced Research Training in Africa (CARTA), Nairobi Kenya.  He holds a PhD in Communication and Information Studies University of Nairobi, Kenya; Master of Publishing and Copyright Studies and Bachelor of Library and Information Studies from the University of Ibadan, Nigeria.
