---
title: Marielle St-Germain
role: École de bibliothéconomie et des sciences de l'information, Université de Montréal
avatar_filename: avatar.jpg
superuser: false
user_groups:
  - Volunteers
---
