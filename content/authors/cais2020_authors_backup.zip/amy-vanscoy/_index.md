---
title: Amy VanScoy
role: Associate Professor, Department of Information Science, University at Buffalo
bio: "Amy VanScoy is an associate professor in the Department of Information Science at the University of Buffalo. Her research focuses on practitioner thinking and professional work in library and information science, including issues of diversity, equity, and inclusion."
avatar_filename: "amy_vanscoy_avatar.jpg"
user_group:
superuser: false
user_groups:
 - Authors
---
# Bio
Amy VanScoy is an associate professor in the Department of Information Science at the University of Buffalo. Her research focuses on practitioner thinking and professional work in library and information science, including issues of diversity, equity, and inclusion.