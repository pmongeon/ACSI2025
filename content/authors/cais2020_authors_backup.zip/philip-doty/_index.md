---
title: Philip Doty
role: University of Texas at Austin
avatar_filename: avatar.jpg
superuser: false
user_groups:
  - Presenters
  - Authors
---
