---
title: Anita Slominska
role: Faculty of Information and Media Studies, Western University
bio: Panel Moderator
avatar_filename: avatar.jpg
superuser: false
user_groups:
  - Authors
---
