---
title: Ashley MacKinnon
role: School of Information Management, Dalhousie University
avatar_filename: avatar.jpg
superuser: false
user_groups:
  - Volunteers
---

# Bio
My name is Ashley and I am from Halifax, Nova Scotia. I am entering my second year at Dalhousie University as a student in the Master of Information program. My research interests revolve around information behaviour ans public history. In my spare time I enjoy studying langages and folklore and cooking. 