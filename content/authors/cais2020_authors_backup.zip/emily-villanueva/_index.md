---
title: Emily Villanueva
role: University of Alberta
bio: Emily Villanueva is a graduate student pursuing her MA/MLIS degrees at the University of Alberta’s School of Library and Information Studies and Media and Technology Studies unit. Her interests reside at the intersection of LIS and the social sciences, with a focus on information behaviours and identities in digital spaces.
avatar_filename: avatar.jpg
superuser: false
user_groups:
  - Authors
---
# Bio
Emily Villanueva is a graduate student pursuing her MA/MLIS degrees at the University of Alberta’s School of Library and Information Studies and Media and Technology Studies unit. Her interests reside at the intersection of LIS and the social sciences, with a focus on information behaviours and identities in digital spaces.