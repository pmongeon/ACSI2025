---
title: Janet Allen
role: Faculty of Information & Media Studies, Western University
avatar_filename: avatar.jpg
bio: Janet is a PhD student in Library and Information Science at the Faculty of Information and Media Studies at Western University.
superuser: false
user_groups:
  - Auhtors
---
# Bio

Janet is a PhD student in Library and Information Science at the Faculty of Information and Media Studies at Western University.
