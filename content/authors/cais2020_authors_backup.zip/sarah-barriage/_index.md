---
title: Sarah Barriage
role: School of Information Science, University of Kentucky
avatar_filename: avatar.jpg
bio: Sarah Barriage is an Assistant Professor in the School of Information Science at the University of Kentucky. Her research interests include the information practices of children and youth and social justice in libraries. She has published articles in _Library & Information Science Research_, _Information Research_, and _Journal of Childhood Studies_.
superuser: false
user_groups:
  - Presenters
  - Authors
---
# Bio

Sarah Barriage is an Assistant Professor in the School of Information Science at the University of Kentucky. Her research interests include the information practices of children and youth and social justice in libraries. She has published articles in _Library & Information Science Research_, _Information Research_, and _Journal of Childhood Studies_.
