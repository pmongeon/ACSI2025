---
title: Martin Nord
role: Faculty of Information & Media Studies, Western University
bio: "Martin Nord is a PhD candidate in Library and Information Science in the Faculty of Information & Media Studies at Western University. His research considers how documents influence individuals as they position themselves in the world as moral selves."
avatar_filename: avatar.jpg
superuser: false
user_groups:
  - Presenters
  - Authors
---

# Bio

Martin Nord is a PhD candidate in Library and Information Science in the Faculty of Information & Media Studies at Western University. His research considers how documents influence individuals as they position themselves in the world as moral selves. 
