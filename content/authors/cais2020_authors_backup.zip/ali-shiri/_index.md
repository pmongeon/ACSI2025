---
title: Ali Shiri
role: University of Alberta
bio: Ali Shiri is a Professor at the School of Library and Information Studies in the University of Alberta, teaching courses in the areas of digital libraries and information organization and retrieval. His research areas centre on digital libraries, search user interfaces, user interaction with digital information and learning and data analytics.
avatar_filename: avatar.jpg
superuser: false
user_groups:
  - Presenters
  - Authors
---
# Bio
Ali Shiri is a Professor at the School of Library and Information Studies in the University of Alberta, teaching courses in the areas of digital libraries and information organization and retrieval. His research areas centre on digital libraries, search user interfaces, user interaction with digital information and learning and data analytics.