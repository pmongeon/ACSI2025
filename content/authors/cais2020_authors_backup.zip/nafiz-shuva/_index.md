---
title: Nafiz Zaman Shuva
role: Faculty of Information & Media Studies, Western University
avatar_filename: nafiz_shuva_avatar.png
bio: Nafiz Zaman Shuva (he/him) is an instructor in the Faculty of Information &
  Media Studies at the University of Western Ontario. Nafiz’s current research
  revolves around migration, information behaviour, critical information needs,
  internationalization of education, open access, and public libraries.
superuser: false
user_groups:
  - Presenters
  - Authors
---
