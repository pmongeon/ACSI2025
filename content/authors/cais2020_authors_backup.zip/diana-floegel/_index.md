---
title: Diana Floegel
role: School of Communication and Information, Rutgers University
avatar_filename: avatar.jpg
bio: Diana Floegel is a doctoral candidate at the Rutgers School of Communication and Information. Their research examines people’s information creation practices, sociotechnical assemblages, and information institutions such as libraries. They have published in _Library and Information Science Research_, _Journal of Documentation_, _Journal of the Association for Information Science and Technology_, and more.
superuser: false
user_groups:
  - Authors
---
# Bio

Diana Floegel is a doctoral candidate at the Rutgers School of Communication and Information. Their research examines people’s information creation practices, sociotechnical assemblages, and information institutions such as libraries. They have published in _Library and Information Science Research_, _Journal of Documentation_, _Journal of the Association for Information Science and Technology_, and more.
