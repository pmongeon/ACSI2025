---
title: Pam McKenzie
role: Faculty of Information & Media Studies, Western University
avatar_filename: avatar.jpg
bio: Pam McKenzie is a Professor in the Faculty of Information and Media Studies at The University of Western Ontario, trying to remember who she is as a researcher after 10 years as an administrator.
superuser: false
user_groups:
  - Presenters
  - Authors
---
# Bio

Pam McKenzie is a Professor in the Faculty of Information and Media Studies at The University of Western Ontario, trying to remember who she is as a researcher after 10 years as an administrator.
