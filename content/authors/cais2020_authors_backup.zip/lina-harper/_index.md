---
title: Lina Harper
role: School of Information Studies, University of Ottawa
bio: "Lina Harper (she/they) is an Ottawa-based library and information studies masters student writing a qualitative research thesis about research data management in the digital humanities. Her academic research interests include  podcasting, Wikipedia contributing and design. Fun fact: Librarians aren't just peripheral, they are foundational to the information science field."
avatar_filename: avatar.jpg
superuser: false
user_groups:
  - Volunteers
---

# Bio

Lina Harper (she/they) is an Ottawa-based library and information studies masters student writing a qualitative research thesis about research data management in the digital humanities. Her academic research interests include  podcasting, Wikipedia contributing and design. Fun fact: Librarians aren't just peripheral, they are foundational to the information science field.