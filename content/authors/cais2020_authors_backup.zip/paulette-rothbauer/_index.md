---
title: Paulette Rothbauer
role: Faculty of Information & Media Studies, Western University
avatar_filename: paulette_rothbauer_avatar.png
bio: Paulette Rothbauer (she/her) is an Associate Professor in the Faculty of
  Information & Media Studies at the University of Western Ontario. She
  researches the reading and library practices of teens, young adults, and more
  recently, of older adults. She is also a member of the team organizing and
  researching the Smoke Signals Radio Show Archives.
superuser: false
user_groups:
  - Presenters
  - Authors
---
