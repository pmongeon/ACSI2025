---
title: Asen O. Ivanov
role: Postdoctoral Fellow, THINC Lab, McLaughlin Library, University of Guelph
avatar_filename: avatar.jpg
bio: Asen O. Ivanov is the Michael Ridley Postdoctoral Fellow in Digital
  Humanities at the College of Arts at the University of Guelph, where he is
  affiliated with the THINC Lab, the School of Languages and Literatures, and
  the Research & Scholarship team at the McLaughlin Library.
superuser: false
user_groups:
  - Presenters
  - Authors
---
# Bio
Asen O. Ivanov is the Michael Ridley Postdoctoral Fellow in Digital Humanities at the College of Arts at the University of Guelph, where he is affiliated with the THINC Lab, the School of Languages and Literatures, and the Research & Scholarship team at the McLaughlin Library.