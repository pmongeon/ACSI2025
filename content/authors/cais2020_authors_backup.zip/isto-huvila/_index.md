---
title: Isto Huvila
role: Uppsala University, Uppsala, Sweden
avatar_filename: avatar.jpg
bio: Isto Huvila is professor in information studies at the Department of ALM, Uppsala University, Sweden. In 2019/20 Huvila worked as a visiting professor at the School of Information at UBC. His primary areas of research include information and knowledge management, information work, documentation, and participatory information practices.
superuser: false
user_groups:
  - Presenters
  - Authors
---
# Bio

Isto Huvila is professor in information studies at the Department of ALM, Uppsala University, Sweden. In 2019/20 Huvila worked as a visiting professor at the School of Information at UBC. His primary areas of research include information and knowledge management, information work, documentation, and participatory information practices.
