---
title: Jessie Hill
role: School of Information Studies, McGill University
avatar_filename: avatar.jpg
superuser: false
user_groups:
  - 
---