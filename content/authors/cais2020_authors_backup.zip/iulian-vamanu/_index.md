---
title: Iulian Vamanu
role: School of Library and Information Science, University of Iowa
avatar_filename: avatar.jpg
bio: Iulian Vamanu is an Assistant Professor in Library and Information Science (University of Iowa). He has been publishing scholarship on cultural heritage and Indigenous museum curatorship, reading practices, Information Ethics education, information evaluation in post-truth times, and the rhetoric of information.
superuser: false
user_groups:
  - Presenters
  - Authors
---
# Bio

Iulian Vamanu is an Assistant Professor in Library and Information Science (University of Iowa). He has been publishing scholarship on cultural heritage and Indigenous museum curatorship, reading practices, Information Ethics education, information evaluation in post-truth times, and the rhetoric of information.
