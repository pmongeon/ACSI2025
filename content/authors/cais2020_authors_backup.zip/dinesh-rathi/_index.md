---
title: Dinesh Rathi
role: "School of Library and Information Studies, University of Alberta"
avatar_filename: avatar.jpg
bio: "Dinesh Rathi is a faculty member at the School of Library and Information Studies, University of Alberta, Edmonton Canada. My current research interests are in the area of Knowledge Management, Social Media and Emerging Technologies, Open Source Software (OSS), and Digital Libraries."
superuser: false
user_groups:
  - Presenters
  - Authors
---

# Bio
Dinesh Rathi is a faculty member at the School of Library and Information Studies, University of Alberta, Edmonton Canada. My current research interests are in the area of Knowledge Management, Social Media and Emerging Technologies, Open Source Software (OSS), and Digital Libraries.