---
title: Marni Harrington
role: Associate Librarian, Faculty of Media & Information Studies, Western University
avatar_filename: avatar.jpg
bio: Marni Harrington (she/her/hers) is an associate librarian in the Faculty of
  Information and Media Studies at Western University. She is the primary
  advisor for Emerging Library and Information Perspectives (ELIP)
superuser: false
user_groups:
  - Authors
---
# Bio
Marni Harrington (she/her/hers) is an associate librarian in the Faculty of
Information and Media Studies at Western University. She is the primary
advisor for Emerging Library and Information Perspectives (ELIP)
