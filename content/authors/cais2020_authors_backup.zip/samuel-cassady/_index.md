---
title: Samuel Cassady
role: Western Libraries, Western University
avatar_filename: avatar.jpg
bio: Samuel is the Head of Collections & Content Strategies at Western
  University, in London, Canada.  Previously, Samuel worked as a Digital
  Information Resources Librarian, also at Western, and was the Head of
  Collections & Technical Services at the Southern Alberta Institute of
  Technology.
superuser: false
user_groups:
  - Authors
---

# Bio
Samuel is the Head of Collections & Content Strategies at Western University, in London, Canada. Previously, Samuel worked as a Digital Information Resources Librarian, also at Western, and was the Head of Collections & Technical Services at the Southern Alberta Institute of Technology.