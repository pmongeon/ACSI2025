---
title: Melissa Seelye
role: Scholarly Communication Coordinator, J. Paul Leonard Library, San
  Francisco State University
avatar_filename: avatar.jpg
bio: "Melissa Seelye (she/her/hers) is the Scholarly Communication Coordinator
  at San Francisco State University. She is an editorial team advisor for
  Emerging Library and Information Perspectives (ELIP) and teaches the Scholarly
  Communication and Open Access Publishing course in the MLIS program at Western
  University.  "
superuser: false
user_groups:
  - Presenters
  - Authors
---
# Bio
Melissa Seelye (she/her/hers) is the Scholarly Communication Coordinator at San Francisco State University. She is an editorial team advisor for Emerging Library and Information Perspectives (ELIP) and teaches the Scholarly Communication and Open Access Publishing course in the MLIS program at Western University.