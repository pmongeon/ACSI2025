---
title: Sharon Farnel
role: University of Alberta
bio: "Sharon Farnel is Head, Metadata Strategies at the University of Alberta Library. She is also an interdisciplinary PhD Candidate at the University of Alberta in Library and Information Studies and Educational Policy Studies. She is a collaborator on the Inuvialuit Voices Project."
avatar_filename: avatar.jpg
superuser: false
user_groups:
  - Authors
---
# Bio
Sharon Farnel is Head, Metadata Strategies at the University of Alberta Library. She is also an interdisciplinary PhD Candidate at the University of Alberta in Library and Information Studies and Educational Policy Studies. She is a collaborator on the Inuvialuit Voices Project.
