---
title: Catherine Johnson
role: Professor Emeritus, Faculty of Information & Media Studies, Western University
avatar_filename: avatar.jpg
bio: Catherine is Professor Emeritus at Western University where she taught for
  many years in the Faculty of Information and Media Studies. One of her main
  teaching areas was in Collection Management where she focused on the
  management of electronic resources. Her current research project is on
  decision-making with regard to the management of electronic journals.
superuser: false
user_groups:
  - Authors
---

# Bio
Catherine is Professor Emeritus at Western University where she taught for many years in the Faculty of Information and Media Studies. One of her main teaching areas was in Collection Management where she focused on the management of electronic resources. Her current research project is on decision-making with regard to the management of electronic journals.