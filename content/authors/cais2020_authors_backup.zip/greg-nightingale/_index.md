---
title: Greg Nightingale
role: Faculty of Information & Media Studies, Western University
avatar_filename: avatar.jpg
bio: Greg Nightingale is a former public librarian and current PhD candidate whose dissertation applies Walter Benjamin’s critical theories to library as place research.
superuser: false
user_groups:
  - Presenters
  - Authors
---
# Bio

Greg Nightingale is a former public librarian and current PhD candidate whose dissertation applies Walter Benjamin’s critical theories to library as place research.
