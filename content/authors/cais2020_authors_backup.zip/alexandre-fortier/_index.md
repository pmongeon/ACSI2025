---
title: Alexandre Fortier
role: Library of Parliament
avatar_filename: avatar.jpg
bio: Alexandre Fortier is the Metadata and Taxonomy Librarian at the Library of Parliament where he manages the library’s taxonomy and is responsible for developing, evaluating and making recommendations for the implementation and use of the metadata describing the Library’s resources. He also teaches subject analysis and metadata development at University of Ottawa.
superuser: false
user_groups:
  - Presenters
  - Authors
---
# Bio

Alexandre Fortier is the Metadata and Taxonomy Librarian at the Library of Parliament where he manages the library’s taxonomy and is responsible for developing, evaluating and making recommendations for the implementation and use of the metadata describing the Library’s resources. He also teaches subject analysis and metadata development at University of Ottawa.
