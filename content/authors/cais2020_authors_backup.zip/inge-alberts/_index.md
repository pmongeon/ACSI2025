---
title: Inge Alberts
role: School of Information Studies, University of Ottawa
bio: Inge Alberts is Associate Professor at the School of Information Studies at the University of Ottawa, as well as Scientific Director at the Cogniva Information Science Research Institute. Her research stems from several years of Information Management consulting experiences in different business spheres combined with a strong interest for information architecture, document theory and automatic classification.
avatar_filename: avatar.jpg
superuser: false
user_groups:
  - Presenters
  - Authors
---
# Bio
Inge Alberts is Associate Professor at the School of Information Studies at the University of Ottawa, as well as Scientific Director at the Cogniva Information Science Research Institute. Her research stems from several years of Information Management consulting experiences in different business spheres combined with a strong interest for information architecture, document theory and automatic classification.
