---
title: Ethel-Jean Gruben
role: Inuvialuit Cultural Centre
avatar_filename: avatar
bio: Ethel-Jean Gruben is Manager of the Inuvialuit Cultural Centre. She is a
  collaborator on the Inuvialuit Voices Project.
superuser: false
user_groups:
  - Authors
---
Ethel-Jean Gruben is Manager of the Inuvialuit Cultural Centre. She is a collaborator on the Inuvialuit Voices Project.